﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapstoneProject;

namespace CapstoneProject
{
    public partial class Scheduler : Form
    {
        public Scheduler()
        {
            InitializeComponent();
        }

        CalendarConnection objConnect;
        string conString;

        DataSet ds;
        DataRow dRow;

        int MaxRows;
        int inc = 0;

        private void Scheduler_Load(object sender, EventArgs e)
        {
            try
            {
                objConnect = new CalendarConnection();
                conString = Properties.Settings.Default.Calendar2String;

                objConnect.connection_string = conString;

                objConnect.Sql = Properties.Settings.Default.SQL;

                ds = objConnect.GetConnection;

                
            }
            catch (Exception err)
            {

                MessageBox.Show(err.Message);
            
            }
        }

        private void initDate_ValueChanged(object sender, EventArgs e)
        {
            

        }

        private void endDate_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var input1 = initDate.Value;
            var input2 = endDate.Value;
            var semesterType = comboBox1.SelectedValue;

            
        }
    }
}