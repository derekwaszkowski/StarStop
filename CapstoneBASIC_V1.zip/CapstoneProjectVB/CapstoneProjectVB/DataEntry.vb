﻿Imports System.Data.SqlClient

Public Class DataEntry

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Me.Hide()
        OutPut.Show()
    End Sub
End Class